# Mango_fruit > 2023-05-09 7:52pm
https://universe.roboflow.com/object-detection/mango_fruit

Provided by a Roboflow user
License: CC BY 4.0

