# MangoDetectionNewProject > 2023-05-07 3:23pm
https://universe.roboflow.com/university-fcqdc/mangodetectionnewproject

Provided by a Roboflow user
License: CC BY 4.0

