# Video_Mango > 2023-08-25 2:48pm
https://universe.roboflow.com/basavachari-boppudi-rmycf/video_mango

Provided by a Roboflow user
License: CC BY 4.0

